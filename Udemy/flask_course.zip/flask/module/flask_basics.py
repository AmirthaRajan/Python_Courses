""" Puppies APP """

from flask import Flask, render_template, request, session, url_for, redirect
from flask_wtf import FlaskForm 
from wtforms import ( BooleanField,StringField,SelectField,RadioField,
                TextAreaField,DateTimeField,TextField,SubmitField)
from wtforms.validators import DataRequired

app = Flask(__name__)

app.config['SECRET_KEY'] = 'mysecretkey'

class InfoForm(FlaskForm):

    breed = StringField("What breed are you ?",validators=[DataRequired()])
    neutred = BooleanField("Has your puppy has been Neutred : ")
    mood = RadioField("Please choose your mood : ",choices=[('mood_one','Happy'),('mood_two','Excited')])
    food = SelectField(u"Pick your favorite food : ",choices=[('chicken','chicken'),('meat','meat'),('fish','fish')])
    feedback = TextAreaField()
    submit = SubmitField('Submit')


@app.route('/',methods=['GET','POST'])
def index():

    form = InfoForm()

    if form.validate_on_submit:
        pass
    return render_template('index.html')

@app.route('/puppy/<name>')
def puppy(name):
    return render_template('puppy.html',name=name)

@app.route('/puppies')
def puppies():
    list_name = ['husky','zitsu','pug']
    return render_template('puppies.html',list_name=list_name)

@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

if __name__ == '__main__':
    app.run(debug=True)