""" Object creation """
from db_basics import db,Puppy

db.create_all()

sam = Puppy('Sammy',5)
spike = Puppy('Spike',4)

db.session.add_all([sam,spike])

db.session.commit()

print(sam.id)
print(spike.id)