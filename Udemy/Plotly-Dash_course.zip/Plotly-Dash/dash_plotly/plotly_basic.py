########## scatter ###############
# import numpy as np
# import plotly.offline as pyo
# import plotly.graph_objs as go

# np.random.seed(42)

# x_data = np.random.randint(1,101,100)
# y_data = np.random.randint(1,101,100)

# data = [go.Scatter(x=x_data,y=y_data,mode='markers',marker=dict(size=12,symbol='o',color='b',line={'width':2}))]
# layout = go.Layout(title='Scatter Plot',xaxis={'title':'X Axis'},yaxis=dict(title='Y Axis'),hovermode='closest')

# fig = go.Figure(data=data,layout=layout)
# pyo.plot(fig,filename='scatter.html')

########### line ###############

# import numpy as np
# import plotly.offline as pyo 
# import plotly.graph_objs as go

# np.random.seed(56)

# x_data = np.linspace(0,1,100)
# y_data = np.random.randn(100)

# trace0 = go.Scatter(x=x_data,y=y_data+5,mode='markers',name='markers')
# trace1 = go.Scatter(x=x_data,y=y_data,mode="lines",name='lines')
# trace2 = go.Scatter(x=x_data,y=y_data-5,mode="markers+lines",name='myPlot')

# data = [trace0,trace1,trace2]
# layout = go.Layout(title="Multi-line Plot",xaxis=dict(title='X Axis'),yaxis=dict(title='Y Axis'))
# fig = go.Figure(data=data,layout=layout)

# pyo.plot(fig,filename='line.html')

########### Bar ###############

# import pandas as pd 
# import plotly.offline as pyo
# import plotly.graph_objs as go

# df = pd.read_csv('../Data/2018WinterOlympics.csv')

# print(df.head())

# bar1 = go.Bar(x=df['NOC'],y=df['Gold'],marker=dict(color='#FFD700'))
# bar2 = go.Bar(x=df['NOC'],y=df['Silver'],marker=dict(color='#C0C0C0'))
# bar3 = go.Bar(x=df['NOC'],y=df['Bronze'],marker=dict(color='#CD7F32'))

# data = [bar1,bar2,bar3]
# layout = go.Layout(title='Olympics Medtals for 2018',xaxis=dict(title='Countries'),yaxis=dict(title='No of Medals'),barmode='stack')

# fig = go.Figure(data=data,layout=layout)

# pyo.plot(fig,filename='bar.html')

########### Bubble ###############

# import pandas as pd 
# import plotly.offline as pyo 
# import plotly.graph_objs as go 

# df = pd.read_csv('../Data/mpg.csv')

# data = [go.Scatter(x=df['horsepower'],y=df['mpg'],mode='markers',text=df['name'],marker=dict(size=df['weight']/100,color=df['cylinders'],showscale=True))]
# layout = go.Layout(title='Car mpg / horsepower',xaxis=dict(title='Horsepower'),yaxis=dict(title='MPG'))

# fig = go.Figure(data=data,layout=layout)

# pyo.plot(fig,filename='bubble.html')

########### Discplot ###############

# import numpy as np
# import plotly.offline as pyo 
# import plotly.figure_factory as ff

# x1 = np.random.randn(200)-2
# x2 = np.random.randn(200)
# x3 = np.random.randn(200)+2
# x4 = np.random.randn(200)+4

# hist_data = [x1,x2,x3,x4]
# group_labels = ['X1','X2','X3','X4']

# fig = ff.create_distplot(hist_data=hist_data,group_labels=group_labels,bin_size=[0.2,0.1,0.3,0.4])

# pyo.plot(fig,filename='distplot.html')

########### Heatmap ###############

import pandas as pd 
import plotly.offline as pyo 
import plotly.graph_objs as go 
from plotly import tools

df1 = pd.read_csv('../Data/2010SitkaAK.csv')
df2 = pd.read_csv('../Data/2010SantaBarbaraCA.csv')
df3 = pd.read_csv('../Data/2010YumaAZ.csv')

trace1 = go.Heatmap(x=df1['DAY'],y=df1['LST_TIME'],z=df1['T_HR_AVG'].values.tolist(),colorscale='Jet',zmin=5,zmax=40)
trace2 = go.Heatmap(x=df2['DAY'],y=df2['LST_TIME'],z=df2['T_HR_AVG'].values.tolist(),colorscale='Jet',zmin=5,zmax=40)
trace3 = go.Heatmap(x=df3['DAY'],y=df3['LST_TIME'],z=df3['T_HR_AVG'].values.tolist(),colorscale='Jet',zmin=5,zmax=40)

fig = tools.make_subplots(rows=1,cols=3,subplot_titles=['StikaAK','SB CA','Yuma AZ'],shared_yaxes=False)

fig.append_trace(trace1,1,1)
fig.append_trace(trace2,1,2)
fig.append_trace(trace3,1,3)

fig['layout'].update(title='Temperature of 3 Cities')

pyo.plot(fig,filename='heatmap.html')