""" Relational DB """
import os
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate

basedir = os.path.abspath(os.path.dirname(__file__))

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///'+os.path.join(basedir,'data_rel.sqlite')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
Migrate(app,db)

class Puppy(db.Model):

    __tablename__ = 'puppies'

    id = db.Column(db.Integer,primarykey=True)
    name = db.Clumn(db.Text)
    toys = db.relationship('Toy',lazy='dynamic',backref='puppy')
    owner = db.relationship('Owner',backref='puppy',uselist=False)

class Toy(db.Model):
    
    __tablename__ = 'toy'
    id = db.Column(db.Integer,primarykey=True)
    item_no = db.Column(db.Integer)
    puppy_id = db.Column(db.Integer,db.ForeignKey('puppies.id'))

class Owner(db.Model):
    
     __tablename__ = 'owner'
    id = db.Column(db.Integer,primarykey=True)
    name = db.Column(db.Text)
    puppy_id = db.Column(db.Integer,db.ForeignKey('puppies.id'))