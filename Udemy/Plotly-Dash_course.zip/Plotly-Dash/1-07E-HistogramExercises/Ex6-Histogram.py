#######
# Objective: Create a histogram that plots the 'length' field
# from the Abalone dataset (../data/abalone.csv).
# Set the range from 0 to 1, with a bin size of 0.02
######

# Perform imports here:




# create a DataFrame from the .csv file:


# create a data variable:





# add a layout




# create a fig from data & layout, and plot the fig
