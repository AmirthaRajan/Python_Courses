# import pandas as pd 
# import dash
# import dash_core_components as dcc 
# import dash_html_components as html
# import plotly.graph_objs as go
# from dash.dependencies import Output, Input 

# server = dash.Dash()

# df = pd.read_csv('../Data/gapminderDataFiveYear.csv')

# year_options = []

# for year in df['year'].unique():
#     year_options.append({'label':str(year),'value':year})

# server.layout = html.Div([
#                         dcc.Graph(id='mygraph'),
#                         dcc.Dropdown(id='years',options=year_options,value=df['year'].min())
#                     ])

# @server.callback(Output('mygraph','figure'),[Input('years','value')])
# def update_graph(selectedyear):
#     df_yr = df[df['year'] == selectedyear]
#     traces = []
#     for continent in df_yr['continent'].unique():
#         df_con = df_yr[df_yr['continent'] == continent]
#         traces.append(go.Scatter(x=df_con['gdpPercap'],
#                                 y=df_con['lifeExp'],
#                                 name=continent,
#                                 mode='markers',
#                                 opacity=0.7,
#                                 marker=dict(
#                                     size=15,
#                                 )))
#     return {'data':traces,'layout':go.Layout(xaxis=dict(title='GDP per gap',type='log'),
#                                             yaxis=dict(title='Life Expectancy'))}

# if __name__ == '__main__':
#     server.run_server(debug=True,port=5000)


import dash
import pandas as pd
import dash_core_components as dcc
import dash_html_components as html
import plotly.graph_objs as go
from dash.dependencies import Output, Input, State

server = dash.Dash()

df = pd.read_csv("../Data/mpg.csv")

dropdown_list = df.columns[:-3]

dropdown_options = [{'label':column,'value':column} for column in dropdown_list]

server.layout = html.Div([
                    html.Div([
                        dcc.Dropdown(id='yaxis',options=dropdown_options,value=dropdown_list[0]),
                    ],style=dict(width='48%',display='inline-block',padding='5')),
                    html.Div([
                        dcc.Dropdown(id='xaxis',options=dropdown_options,value=dropdown_list[-1])
                    ],style=dict(width='48%',display='inline-block',padding='5')),
                    html.Div([
                        html.Button(id='submit',n_clicks=0,children="submit")
                    ]),
                    dcc.Graph(id='feature-graph')
                ],style=dict(padding='10',textAlign='center'))

@server.callback(Output('feature-graph','figure'),[Input('submit','n_clicks')],[State('yaxis','value'),State('xaxis','value')])
def plot_graph(clicks,yaxis_name,xaxis_name):
    return {
        'data': [go.Scatter(x=df[xaxis_name],y=df[yaxis_name],text=df['name'],opacity=0.7,mode='markers',marker=dict(size=10))],
        'layout': go.Layout(title=f" {yaxis_name} vs {xaxis_name} ",xaxis=dict(title=xaxis_name),yaxis=dict(title=yaxis_name))
    }

if __name__ == '__main__':
    server.run_server(debug=True,port=5000)
