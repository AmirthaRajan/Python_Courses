import dash
import dash_html_components as html
import dash_core_components as dcc
import numpy as np
import plotly.graph_objs as go
from dash.dependencies import Input, Output

app = dash.Dash()

colors = { 'background' : 'rgb(11 57 55)', 'text' : '#bad9d3'}

x_data = np.random.randint(1,101,100)
y_data = np.random.randint(1,101,100)

# app.layout = html.Div(children=[
#                     html.H1("hello world",style={'color':colors['text'],'textAlign':'center'}),
#                     dcc.Graph(id='barplot',
#                     figure={
#                         'data': [
#                             {'x':[1,2,3],'y':[3,2,6],'name':'NYC','type':'bar'},
#                             {'x':[1,2,3],'y':[2,5,4],'name':'BC','type':'bar'}
#                         ],
#                         'layout' : {
#                             'plot_bgcolor':colors['background'],
#                             'paper_bgcolor':colors['background'],
#                             'font' : {'color':colors['text']},
#                             'title' : 'Bar Plots!'
#                         }

#                     })],
#                     style={'backgroundColor':colors['background']})


app.layout = html.Div(children=[
                        dcc.Graph(id='plot1',
                            figure = {
                                'data':[
                                    go.Scatter(x=x_data,y=y_data,mode='markers',marker=dict(size=6,color='red',line=dict(width=1)),name='plot1')
                                    ],
                                'layout': go.Layout(title='Scatter Plot')
                            }),
                        dcc.Graph(id='plot2',
                            figure={
                                'data':[
                                    go.Scatter(x=x_data,y=y_data,mode='markers',marker=dict(size=6,color='green'),name='plot2')
                                    ],
                                'layout': go.Layout(title='Scatter Plot')
                            })
                        ])

app.layout = html.Div(children=[
                            html.Div([
                                html.Label("Dropdown"),
                                dcc.Dropdown(options=[{'label':'NewYork','value':'NY'},
                                                    {'label':'San Fransico','value':'SF'}])
                            ]),
                            html.Div([
                                html.Label('Slider'),
                                dcc.Slider(min=-10,max=10,step=0.5,value=0,marks={i:i for i in range(-10,10)})
                            ]),
                            html.Div([
                                html.P(html.Label('Radios')),
                                dcc.RadioItems(options=[{'label':'NewYork','value':'NY'},
                                                    {'label':'San Fransico','value':'SF'}])
                            ]),
                            html.Div([
                                html.Label('Bind Input'),
                                dcc.Input(id="myInt",value="My Initial value"),
                                html.Div(id='myOut')
                            ])

                        ])
@app.callback(Output(component_id='myOut',component_property='children'),
            [Input(component_id='myInt',component_property='value')])
def bindingInt(input):
    return f"You have entered '{input}'"

if __name__ == '__main__':
    app.run_server(debug=True,port=5000)
