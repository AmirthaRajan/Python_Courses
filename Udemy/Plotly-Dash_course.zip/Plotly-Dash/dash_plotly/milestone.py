import dash
import dash_html_components as html
import dash_core_components as dcc
from dash.dependencies import Output, Input
from datetime import datetime

app = dash.Dash()


app.layout = html.Div([
                    html.Div([
                        html.H1("Flight Live status"),
                        html.Iframe(src="https://www.flightradar24.com/13.09,80.28/8",width=1200,height=400)
                    ]),
                    html.Div([
                        dcc.Interval(id='interval',interval=8000,n_intervals=0)
                    ]),
                    html.Div([
                        html.H3(id="time")
                    ])
                ])

@app.callback(Output('time','children'),[Input('interval','n_intervals')])
def update_status(n_intervals):
    return datetime.now()

if __name__ == "__main__":
    app.run_server()    